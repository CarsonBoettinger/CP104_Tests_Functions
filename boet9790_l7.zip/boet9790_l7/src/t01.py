"""
-------------------------------------------------------
Lab 7 Test 1
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""

from functions import hi_lo_game

high = 100
count = hi_lo_game(high)
print(f"Total number of guesses: {count}")