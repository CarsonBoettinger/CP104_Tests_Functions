"""
-------------------------------------------------------
Lab 7 Test 2
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
from functions import power_of_two

print(power_of_two(3))  
print(power_of_two(4))
print(power_of_two(248))

