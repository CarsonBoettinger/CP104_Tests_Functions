"""
-------------------------------------------------------
Lab 7 Test 10
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""

from functions import employee_payroll

total, average = employee_payroll()
print(f"Total net employee wages: ${total:.2f}")
print(f"Average employee net wages: ${average:.2f}")
