"""
-------------------------------------------------------
Lab 7 Test 7
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""

from functions import meal_costs

b_total, l_total, s_total, a_total = meal_costs()
print(f"Total breakfasts cost: ${b_total:.2f}")
print(f"Total lunches cost: ${l_total:.2f}")
print(f"Total suppers cost: ${s_total:.2f}")
print(f"All meals cost: ${a_total:.2f}")
