"""
-------------------------------------------------------
Lab 7 Test 4
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
from functions import sum_squares

target = 26
final = sum_squares(target)
    
print(f"The final sum of squares greater than or equal to {target} is: {final}")
