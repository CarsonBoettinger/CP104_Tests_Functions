"""
-------------------------------------------------------
Functions
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
from random import randint

def hi_lo_game(high):
    """
    -------------------------------------------------------
    Plays a random higher-lower guessing game.
    Use: count = hi_lo_game(high)
    -------------------------------------------------------
    Parameters:
        high - maximum random value (int > 1)
    Returns:
        count - the number of guesses the user made (int)
    -------------------------------------------------------
    """
    count = 0
    number = randint(1, high)
    
    while True:
        guess = int(input(f"Guess a number between 1 and {high}: "))
        count += 1
        if guess < number:
            print("Too low, try again.")
        elif guess > number:
            print("Too high, try again.")
        else:
            print(f"Congratulations! You guessed the number {number} correctly.")
            break

    return count

def power_of_two(target):
    """
    -------------------------------------------------------
    Determines the nearest power of 2 greater than or equal to
    a given target.
    Use: power = power_of_two(target)
    -------------------------------------------------------
    Parameters:
        target - value to find nearest power of 2 (int >= 0)
    Returns:
        power - first power of 2 >= target (int)
    -------------------------------------------------------
    """
    if target <= 1:
        power = 1

    power = 1
    while power < target:
        power *= 2

    return power


def sum_squares(target):
    """
    -------------------------------------------------------
    Determines the sum of squares closest to, and greater than or
    equal to, a target value.
    Use: final = sum_squares(target)
    -------------------------------------------------------
    Parameters:
        target - target value (int >= 0)
    Returns:
        final - the final sum of squares >= target (int)
    -------------------------------------------------------
    """
    final = 0
    current = 0
    
    if target == 0:
        final = 1
    while final < target:
        current += 1
        final += current * current

    return final
# functions.py

def meal_costs():
    """
    -------------------------------------------------------
    Asks a user the costs of breakfast, lunch, and supper for each
    day the user was away. Assumes there is at least one day, and
    after entering data for each day asks the user whether they want
    to enter data for another day. Calculates total costs for meals.
    Use: b_total, l_total, s_total, a_total = meal_costs()
    -------------------------------------------------------
    Returns:
        b_total - total breakfasts cost (float)
        l_total - total lunches cost (float)
        s_total - total suppers cost (float)
        a_total - all meals cost (float)
    ------------------------------------------------------
    """
    day = 1
    b_total = 0
    l_total = 0
    s_total = 0

    while True:
        print(f"For Day {day}\n")
        breakfast_cost = float(input("How much was breakfast? $"))
        lunch_cost = float(input("How much was lunch? $"))
        supper_cost = float(input("How much was supper? $"))

        total_cost = breakfast_cost + lunch_cost + supper_cost
        print(f"Your total for the day was ${total_cost:.2f}\n")

        b_total += breakfast_cost
        l_total += lunch_cost
        s_total += supper_cost

        choice = input("Were you away another day (Y/N)? ")
        if choice != 'Y':
            break
        day += 1

    a_total = b_total + l_total + s_total

    return b_total, l_total, s_total, a_total

# functions.py

TAX_RATE = 0.03625
OVERTIME_RATE = 1.5
MAX_REGULAR_HOURS = 40

def employee_payroll():
    """
    -------------------------------------------------------
    Calculates and returns the weekly employee payroll for all employees
    in an organization. For each employee, ask the user for the employee ID
    number, the hourly wage rate, and the number of hours worked during a week.
    An employee number of zero indicates the end of user input.
    Each employee is paid 1.5 times their regular hourly rate for all hours
    over 40. A tax amount of 3.625 percent of gross salary is deducted.
    Use: total, average = employee_payroll()
    -------------------------------------------------------
    Returns:
        total - total net employee wages (i.e. after taxes) (float)
        average - average employee net wages (float)
    ------------------------------------------------------
    """
    total_wages = 0
    employee_count = 0

    while True:
        employee_id = int(input("Enter the employee ID (0 to end): "))
        if employee_id == 0:
            break

        wage_rate = float(input("Enter the hourly wage rate: "))
        hours_worked = float(input("Enter the number of hours worked: "))

        if hours_worked > MAX_REGULAR_HOURS:
            regular_pay = MAX_REGULAR_HOURS * wage_rate
            overtime_pay = (hours_worked - MAX_REGULAR_HOURS) * wage_rate * OVERTIME_RATE
            gross_pay = regular_pay + overtime_pay
        else:
            gross_pay = hours_worked * wage_rate

        tax_deduction = gross_pay * TAX_RATE
        net_pay = gross_pay - tax_deduction

        total_wages += net_pay
        employee_count += 1

    if employee_count == 0:
        total_wages = 0

    average_wages = total_wages / employee_count
    return total_wages, average_wages

