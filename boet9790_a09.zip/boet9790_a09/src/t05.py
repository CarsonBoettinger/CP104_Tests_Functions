"""
-------------------------------------------------------
Assignment 9 Test 5
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""
from functions import student_stats


file_handle = open("students.txt", "r", encoding="utf-8")


l_id, h_id, avg = student_stats(file_handle)
print(f"Lowest Mark ID: {l_id}")
print(f"Highest Mark ID: {h_id}")
print(f"Average Mark: {avg:.2f}")


file_handle.close()