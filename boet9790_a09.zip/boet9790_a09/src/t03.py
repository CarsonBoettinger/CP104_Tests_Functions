"""
-------------------------------------------------------
Assignment 9 Test 3
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""
from functions import file_statistics


file_handle = open("addresses.txt", "r", encoding="utf-8")

ucount, lcount, dcount, wcount, rcount = file_statistics(file_handle)
print(f"Upper-case letters: {ucount}")
print(f"Lower-case letters: {lcount}")
print(f"Digits: {dcount}")
print(f"White-space characters: {wcount}")
print(f"Remaining characters: {rcount}")

file_handle.close()