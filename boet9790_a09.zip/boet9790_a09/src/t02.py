"""
-------------------------------------------------------
Assignment 9 Test 2
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""
from functions import read_integers


file_handle = open("numbers.txt", "r", encoding="utf-8")


result = read_integers(file_handle)
print(result)

file_handle.close()