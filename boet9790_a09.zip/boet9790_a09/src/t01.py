"""
-------------------------------------------------------
Assignment 9 Test 1
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""

from functions import file_top

file_handle = open("students.txt", "r", encoding="utf-8")

file_top(file_handle, 5)

file_handle.close()
