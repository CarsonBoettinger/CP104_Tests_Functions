"""
-------------------------------------------------------
Assignment 9 Test 4
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""
from functions import line_numbering

fh_read = open("wilde.txt", "r", encoding="utf-8")

fh_write = open("numbered_wilde.txt", "w", encoding="utf-8")


line_numbering(fh_read, fh_write)

fh_read.close()
fh_write.close()