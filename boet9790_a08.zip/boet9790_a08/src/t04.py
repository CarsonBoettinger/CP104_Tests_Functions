"""
-------------------------------------------------------
Assignment 8 Test 4
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
from functions import valid_isbn

test_cases = [
        '978-3-12148410--0',
        '978-3-16-148410-0',
        '979-1-937128-21-8',
        '978-0-306-40615-7'
    ]

for isbn in test_cases:
    result = valid_isbn(isbn)
    print(f"valid_isbn('{isbn}') -> {result}")