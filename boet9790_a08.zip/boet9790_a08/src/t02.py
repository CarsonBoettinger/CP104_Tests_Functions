"""
-------------------------------------------------------
Assignment 8 Test 1
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""

from functions import pluralize
test_words = ['city', 'student']
for word in test_words:
    pluralized_word = pluralize(word)
    print(f"pluralize('{word}') -> {pluralized_word}")