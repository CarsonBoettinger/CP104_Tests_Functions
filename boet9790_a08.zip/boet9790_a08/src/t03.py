"""
-------------------------------------------------------
Assignment 8 Test 3
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
from functions import common_end

test_cases = [
        ('abc', 'ABC'),
        ('running', 'jumping'),
        ('apple', 'pineapple')]

for str1, str2 in test_cases:
    result = common_end(str1, str2)
    print(f"common_end('{str1}', '{str2}') -> {result}")