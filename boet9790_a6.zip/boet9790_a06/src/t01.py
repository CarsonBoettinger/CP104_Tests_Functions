"""
-------------------------------------------------------
Assignment 6 Test 1
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""

from functions import total_wins


print("Test Case 1:")
result1 = total_wins()
print(result1)
print()

print("Test Case 2:")
result2 = total_wins()
print(result2)
print()

print("Test Case 3:")
result3 = total_wins()
print(result3)
