"""
-------------------------------------------------------
Assignment 6 Test 4
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""

from functions import count_of_digits

result1 = count_of_digits(-1024)
print(result1)

result2 = count_of_digits(0)
print(result2)

result3 = count_of_digits(987654321)
print(result3)