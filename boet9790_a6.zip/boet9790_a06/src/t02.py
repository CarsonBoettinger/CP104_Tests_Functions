"""
-------------------------------------------------------
Assignment 6 Test 2
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
from functions import detect_prime

result1 = detect_prime(131)
print(result1)

result2 = detect_prime(20)
print(result2)

result3 = detect_prime(7)
print(result3)