"""
-------------------------------------------------------
Functions
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""

def total_wins():
    """
    total_wins() -> tuple

    Asks the user to enter a series of strings representing the output of a game.
    The function returns a tuple containing two numbers: the count of appearances of "purple"
    and the count of appearances of "gold" in the input.

    Sample Execution:
    total_wins() ->
    Enter the winning team: purple
    Enter the winning team: purple
    Enter the winning team: yellow
    Enter the winning team: purple
    Enter the winning team: gold
    Enter the winning team: gold
    Enter the winning team: orange
    Enter the winning team:
    (3, 2)
    """

    purple_count = 0
    gold_count = 0

    while True:
        team = input("Enter the winning team: ").lower()

        if team == '':
            break

        if team == 'purple':
            purple_count += 1
        elif team == 'gold':
            gold_count += 1

    return purple_count, gold_count

def detect_prime(number):
    """
    -------------------------------------------------------
    Determines if number is a prime number.
    Use: prime = detect_prime(number)
    -------------------------------------------------------
    Parameters:
        number - an integer (int > 1)
    Returns:
        prime - True if number is prime, False otherwise (bool)
    ------------------------------------------------------
    """
    if number <= 1:
        prime = False
    else:
        divisor = 2
        prime = True
        while divisor * divisor <= number:
            if number % divisor == 0:
                prime = False
                break
            divisor += 1

    return prime


def interest_table(principal_amount, interest_rate, payment):
    """
    -------------------------------------------------------
    Prints a table of monthly interest and payments on a loan.
    Use: interest_table(principal_amount, interest_rate, payment)
    -------------------------------------------------------
    Parameters:
        principal_amount - original value of a loan (float > 0)
        interest_rate - yearly interest interest_rate as a % (float >= 0)
        payment - the monthly payment (float > 0)
    Returns:
        None
    ------------------------------------------------------
    """
    principal = principal_amount
    monthly_interest_rate = interest_rate / 100 / 12
    month = 1

    print(f"Principal: ${principal:.2f}")
    print(f"Interest Rate: {interest_rate:.2f}%")
    print(f"Monthly Payment: ${payment:.2f}")
    print("----------------------------------")
    print("Month   Interest   Payment   Balance")
    print("----------------------------------")

    while principal > 0:
        interest = principal * monthly_interest_rate
        if payment >= principal + interest:
            payment = principal + interest
        balance = principal + interest - payment

        print(f"    {month}    {interest:.2f}    {payment:.2f}    {balance:.2f}")

        principal = balance
        month += 1

    print("----------------------------------")

    return None


def count_of_digits(number):
    """
    -------------------------------------------------------
    Counts the number of digits in an integer.
    Use: digits = count_of_digits(number)
    -------------------------------------------------------
    Parameters:
        number - an integer (int)
    Returns:
        digits - the number of digits in number (int)
    ------------------------------------------------------
    """
    count = 0
    num = abs(number)

    while num > 0:
        num //= 10
        count += 1

    return count

def factor_summation(number):
    """
    -------------------------------------------------------
    Determines the sum of factors of an integer not including
    the integer itself. An integer's factors are the whole numbers
    that the integer can be evenly divided by.
    Use: total = factor_summation(number)
    -------------------------------------------------------
    Parameters:
        number - a positive integer (int >= 1)
    Returns:
        total - the total of number's factors (int)
    ------------------------------------------------------
    """
    total = 0
    divisor = 1

    while divisor <= number // 2:
        if number % divisor == 0:
            total += divisor
        divisor += 1

    return total


