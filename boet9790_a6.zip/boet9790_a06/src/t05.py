"""
-------------------------------------------------------
Assignment 6 Test 5
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
from functions import factor_summation
result1 = factor_summation(6)
print(result1)

result2 = factor_summation(12)
print(result2)

result3 = factor_summation(28)
print(result3)