"""
-------------------------------------------------------
Assignment 6 Test 3
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
from functions import interest_table

interest_table(750, 8.5, 200)
print()

interest_table(1000, 6.0, 150)
print()

interest_table(1200, 10.0, 100)