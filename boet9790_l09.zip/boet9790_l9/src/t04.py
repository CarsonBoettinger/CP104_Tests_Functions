"""
-------------------------------------------------------
Test 4 Lab 9
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-17"
-------------------------------------------------------
"""
from functions import validate_code

product_code = input("please input product code")

category, digits, qualifiers = validate_code(product_code)