"""
-------------------------------------------------------
Test 10 Lab 9
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-17"
-------------------------------------------------------
"""
from functions import text_analyze

sample_text = "Hello 123 World\nThis is a test."

 
upper, lower, digits, whitespace = text_analyze(sample_text)

print(f"Uppercase letters: {upper}")
print(f"Lowercase letters: {lower}")
print(f"Digits: {digits}")
print(f"Whitespace: {whitespace}")