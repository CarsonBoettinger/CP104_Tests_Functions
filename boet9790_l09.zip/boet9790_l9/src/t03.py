"""
-------------------------------------------------------
Test 3 Lab 9
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-17"
-------------------------------------------------------
"""
from functions import parse_code

product_code = input("please input product code")
pc, pi, pq = parse_code(product_code)