"""
-------------------------------------------------------
Test 1 Lab 9
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-17"
-------------------------------------------------------
"""

from functions import is_hydroxide

chemicals = ['NaOH', 'H2O', 'CaCO3', 'Mg(OH)2']

for chemical in chemicals:
    result = is_hydroxide(chemical)
    print(f"{chemical}: {result}")
