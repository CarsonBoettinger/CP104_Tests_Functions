"""
-------------------------------------------------------
Assignment 6 Test 5
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
from functions import range_addition
start = int(input("Enter the starting value: "))
increment = int(input("Enter the increment value: "))
count = int(input("Enter the count of values: "))

total = range_addition(start, increment, count)
print(f"The sum of the range is: {total}")