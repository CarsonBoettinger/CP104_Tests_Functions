"""
-------------------------------------------------------
Assignment 6 Test 1
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
from functions import calc_factorial

test_cases = [7, 4]

for number in test_cases:
    factorial = calc_factorial(number)
    print(f"{number}! = {factorial}")
