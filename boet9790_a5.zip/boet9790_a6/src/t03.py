"""
-------------------------------------------------------
Assignment 6 Test 3
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""

from functions import arrow_up


arrow_up(4)
arrow_up(5)
arrow_up(6)
