"""
-------------------------------------------------------
Functions
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""

def calc_factorial(number):
    """
    -------------------------------------------------------
    Calculates and returns the factorial of number.
    Use: product = calc_factorial(number)
    -------------------------------------------------------
    Parameters:
        number - number to factorial (int > 0)
    Returns:
        product - number! (int)
    ------------------------------------------------------
    """
    product = 1
    for i in range(1, number + 1):
        product *= i
    return product

def calories_treadmill(per_min, minutes):
    """
    -------------------------------------------------------
    Prints a table of the number of calories burned every five minutes
    given the number of calories burned per minute (per_min) and the
    total number of minutes run (minutes).
    Use: calories_treadmill(per_min, minutes)
    -------------------------------------------------------
    Parameters:
        per_min - calories burned per minute (float)
        minutes - total number of minutes run (int)
    Returns:
        None
    ------------------------------------------------------
    """
    print("  5  {:.1f}".format(per_min * 5))
    for i in range(10, minutes + 1, 5):
        calories_burned = per_min * i
        print("{:3d}  {:.1f}".format(i, calories_burned))
        
    return None
        


def arrow_up(rows):
    """
    Print an arrow pointing up made of '#' characters.

    rows: The number of rows for the arrow.
    rows: int
    Use: arrow_up(rows)
    """
    for i in range(rows):
        if i == 0:
            print(" " * (rows - 1) + "#")
        else:
            print(" " * (rows - i - 1) + "#" + " " * (2 * i - 1) + "#")
    
    return None
def multiplication_table(start_num, stop_num):
    """
    Prints a multiplication table for values from start_num to stop_num.

    Parameters:
        start_num : int
            The range start value.
        stop_num : int
            The range stop value.

    Returns:
        None
    Use: multiplication_table(start_num, stop_num)
    """
    table = ""
    for x in range(start_num, stop_num + 1):
        table += " " * 3
        for i in range(start_num, stop_num + 1):
            table += "%3d" % (i) + " "
        table += "\n   "

    s = ""
    for y in range(start_num, stop_num + 1):
        s += "-"*4
    table += s[:-1] + "\n"

    for x in range(start_num, stop_num + 1):
        table += str(x) + "|"
        for y in range(start_num, stop_num + 1):
            table += "%3d" % (x * y) + " "
        table += "\n"
    

    print(table)
    return None

def range_addition(start, increment, count):
    """
    -------------------------------------------------------
    Uses a for loop to sum values from start by increment.
    Use: total = range_addition(start, increment, count)
    -------------------------------------------------------
    Parameters:
        start - the range start value (int)
        increment - the range increment (int)
        count - the number of values in the range (int)
    Returns:
        total - the sum of the range (int)
    ------------------------------------------------------
    """
    total = 0
    for i in range(count):
        total += start
        start += increment
    return total

            


