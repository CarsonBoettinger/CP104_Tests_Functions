"""
-------------------------------------------------------
Assignment 6 Test 2
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
from functions import calories_treadmill

calories_treadmill(4.1, 20)

calories_treadmill(3.5, 25)

calories_treadmill(5.2, 15)