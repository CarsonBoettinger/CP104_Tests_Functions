"""
-------------------------------------------------------
Lab 1 Question 7
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-15"
-------------------------------------------------------
COMPLETE
"""

FLYER = int(input("Number of flyers:"))
VOLENTEERS = int(input("Number of volunteers:"))

END_FLYER = FLYER // VOLENTEERS
LEFT_OVER = FLYER % VOLENTEERS

print("Flyers per volunteer:", END_FLYER)
print("Flyers left over:", LEFT_OVER)
