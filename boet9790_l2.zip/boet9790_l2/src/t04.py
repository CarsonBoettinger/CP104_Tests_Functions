"""
-------------------------------------------------------
Lab 1 Question 4
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-15"
-------------------------------------------------------
"""


n1 = int(input("First numerator:"))
d1 = int(input("First denominator:"))
n2 = int(input("Second numerator:"))
d2 = int(input("Second denominator:"))

total_numdenom = (n1 * n2) / (d1*d2)

print("Product: ", total_numdenom)