"""
-------------------------------------------------------
Lab 1 Question 1
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-15"
-------------------------------------------------------
"""
FREEZING = 32
temp_cel = int(input("Tempature (C):"))

temp_2 = temp_cel * (9/5) + FREEZING

print("Tempature (F)", temp_2)
