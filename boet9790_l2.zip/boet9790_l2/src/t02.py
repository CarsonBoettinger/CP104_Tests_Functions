"""
-------------------------------------------------------
Lab 1 Question 2
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-15"
-------------------------------------------------------
"""
FREEZING = 32
temp_farien = int(input("Tempature (F):"))

temp_cel = (temp_farien - FREEZING) *(5/9)

print("Tempature (C):", temp_cel)