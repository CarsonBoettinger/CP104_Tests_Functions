"""
-------------------------------------------------------
Lab 1 Question 8
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-15"
-------------------------------------------------------
"""
HEIGHT = float(input("Enter your height (m):"))
WEIGHT = float(input("Enter your weight (kg):"))
LIM_BMI = int(input("Enter your upper limit BMI (23 if you are from South East Asia and Southern China, 25 for everyone else):"))

BMI = WEIGHT/(HEIGHT*HEIGHT)
ADJUST_BMI = BMI / LIM_BMI

print("Body Mass Index (kg/m^2) =", BMI)
print("BMI Prime = ", ADJUST_BMI)
