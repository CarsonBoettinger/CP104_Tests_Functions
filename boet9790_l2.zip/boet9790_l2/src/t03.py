"""
-------------------------------------------------------
Lab 1 Question 3
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-15"
-------------------------------------------------------
"""
COSTLRG_DOG = 75
COSTSML_DOG = 50
LARGE_DOG = int(input("Number of large dogs groomed:"))
SMALL_DOG = int(input("Number of small dogs groomed:"))

total_dollars = (LARGE_DOG * COSTLRG_DOG ) + (SMALL_DOG * COSTSML_DOG)


print("Total earned for the day: $", total_dollars)