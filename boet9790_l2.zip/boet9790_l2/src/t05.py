"""
-------------------------------------------------------
Lab 1 Question 5
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-15"
-------------------------------------------------------
"""
HROP = float(input("Hourly rate of pay:"))

HWIW = float(input("Hours worked in the week:"))

total_pay = HROP * HWIW

print("Total pay for the week: $", total_pay)