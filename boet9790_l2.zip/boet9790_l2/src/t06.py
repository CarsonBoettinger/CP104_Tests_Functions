"""
-------------------------------------------------------
Lab 1 Question 6
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-15"
-------------------------------------------------------
"""

# Ask the user for input
principal = float(input("Mortgage principal ($): "))
years = int(input("Number of years: "))
annual_interest_rate = float(input("Yearly interest rate (%): "))
# Convert yearly interest rate to monthly interest rate
monthly_interest_rate = (annual_interest_rate / 100) / 12

# Convert number of years to number of monthly payments
num_payments = years * 12

# Calculate the monthly mortgage payment using the formula
monthly_payment = principal * (monthly_interest_rate * (1 + monthly_interest_rate)**num_payments) / ((1 + monthly_interest_rate)**num_payments - 1)
# Print the monthly payment
print("The monthly payments are:", monthly_payment)

