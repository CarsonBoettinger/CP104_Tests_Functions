"""
-------------------------------------------------------
Exam Task 1 Function Definitions
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-08-25"
-------------------------------------------------------
"""


def even_avg(values):
    """
    -------------------------------------------------------
    Returns the average (integer, rounded down) of all even numbers
    in values. If values has no even numbers, the average is 0.
    Use: ea = even_avg(values)
    -------------------------------------------------------
    Parameters:
        values - a list of values (list of int)
    Returns‌‌​​‌​​‌​​​​‌​​​‌‌​​‌​‌​‌‌‌​:
        ea - the average of the even numbers in values (int)
    -------------------------------------------------------
    """
    count = 0 
    total =0
    # your code here
    for i in values:
        if (i % 2) == 0:
            total= total+i
            count= count+1
        else:
            total = total +0
            count = count + 0
    if count == 0:
        ea = 0
    else:
        ea = total/count
    return ea