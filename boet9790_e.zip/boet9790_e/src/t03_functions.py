"""
-------------------------------------------------------
Exam Task 3 Function Definitions
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-12-13"
-------------------------------------------------------
"""

def upper_vowels(string):
    """
    -------------------------------------------------------
    Converts vowels in a string to upper-case, all other 
    letters to lower-case. Non letters are left unchanged.
    Vowels include: aeiou.
    Use: altered = upper_vowels(string)
    -------------------------------------------------------
    Parameters:
        string - string to process (str)
    Returns‌‌​​‌​​‌​​​​‌​​​‌‌​​‌​‌​‌‌‌​:
        altered - the resulting string (str)
    -------------------------------------------------------
    """
    vowels = "aeiouAEIOU"
    altered = ""
    # Your code here
    for char in string:
        if char.isalpha() and char.lower() in vowels:
            altered+= char.upper()
        elif string == '':
            altered = ''
        else:
            altered+=char.lower()
        
    return altered
    
    