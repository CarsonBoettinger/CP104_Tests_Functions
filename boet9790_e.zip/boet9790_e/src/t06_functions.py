"""
-------------------------------------------------------
Exam Task 6 Function Definitions
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-08-25"
-------------------------------------------------------
"""


def multiply_list(values):
    """
    -------------------------------------------------------
    Multiplies the value of each element of values by its index.
    Use: multiply_list(values)
    -------------------------------------------------------
    Parameters:
        values - list of elements to multiply (list of int)
    Returns‌‌​​‌​​‌​​​​‌​​​‌‌​​‌​‌​‌‌‌​:
        None
    -------------------------------------------------------
    """

    # Your code here
    for i in range(len(values)):
        values[i] *= i
    return None
