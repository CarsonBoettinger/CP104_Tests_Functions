"""
-------------------------------------------------------
Exam Task 4 Function Definitions
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-12-13"
-------------------------------------------------------
"""

def draw_x(height):
    """
    -------------------------------------------------------
    Prints a X shape height characters high.
    Use: draw_x(height)
    -------------------------------------------------------
    Parameters:
        height - maximum height in characters of X shape (int >= 3)
    Returns‌‌​​‌​​‌​​​​‌​​​‌‌​​‌​‌​‌‌‌​:
        None
    -------------------------------------------------------
    """
    # Your code here
    if height < 3:
        print("Height must be greater than 3")
        
    for i in range(height):
        for j in range(height):
            if j == i or j == height - i -1:
                print("#",end='')
            else:
                print("",end='')
            if j == height -1:
                print()
            
            
    return None
            