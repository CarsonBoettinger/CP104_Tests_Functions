"""
-------------------------------------------------------
Exam Task 2 Function Definitions
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-08-25"
-------------------------------------------------------
"""
# Constants
DAY = 1
# Your constants here


def rainfall():
    """
    -------------------------------------------------------
    Asks the user for daily rainfall (in mm) from the keyboard.
    The function stops asking for rainfall when the user enters -1.
    The function returns:
        the total number of dry days (rainfall lower than 4mm)
        the total number of damp days (rainfall 4mm - 8mm)
        the total number of wet days (rainfall greater than 8mm)
        the average rainfall for all days (rounded down)
    Do all inputs and calculations in integer.
    Use: dry_days, damp_days, wet_days, avg = rainfall()
    -------------------------------------------------------
    Returns‌‌​​‌​​‌​​​​‌​​​‌‌​​‌​‌​‌‌‌​:
        dry_days - number of dry days (int)
        damp_days - number of damp days (int)
        wet_days - number of wet days (int)
        avg - average rainfall of all days (int)
    -------------------------------------------------------
    """
    dry_days = 0
    damp_days = 0
    wet_days = 0
    total = 0
    rain = int(input("please input the amount of rainfall (any negative to close)"))

    # your code here
    while rain > 0:
        if rain < 4:
            dry_days= dry_days+DAY
        elif rain >= 4 and rain < 8:
            damp_days = damp_days + DAY
        elif rain >8:
            wet_days = wet_days +DAY
        total = total + rain
        rain = int(input("please input the amount of rainfall (any negative to close)"))
    avg = total / (dry_days + damp_days + wet_days)
        
        
        

    return wet_days, damp_days, dry_days, avg
