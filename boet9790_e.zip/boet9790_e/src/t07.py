"""
-------------------------------------------------------
Testing for Task 7: line_lengths
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-08-25"
-------------------------------------------------------
"""
# Imports
from t07_functions import line_lengths
# your imports here

# Your code here
f_in = open('source.txt','r')
f_short= open('output_1.txt','w')
f_long= open('output_2.txt','w')

short_lines, long_lines = line_lengths(f_in, f_short, f_long, 16)

f_in.close()
f_short.close()
f_long.close()

print(f"Number of lines in output file 1: {short_lines}")
print(f"Number of lines in output file 1: {long_lines}")