"""
-------------------------------------------------------
Lab 1 Question 6
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-15"
-------------------------------------------------------
"""
# Calculate total pay
salary = 2500.0
bonus = 1200.0
pay = salary + bonus
print("Your pay is", pay)