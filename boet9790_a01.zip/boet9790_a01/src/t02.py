"""
-------------------------------------------------------
Assignment 1 Question 2
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------

"""
age = int(input("What is your age?"))
band = str(input("What is your favourite band?"))

print(f"I am {age} years old and {band} is my favourite band.")