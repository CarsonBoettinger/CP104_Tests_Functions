"""
-------------------------------------------------------
Assignment 1 Question 3
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------

"""
KM = 1.61
miles = float(input("Length in miles:"))

kms = miles * KM

print(f"Length in km: {kms:.2f}")