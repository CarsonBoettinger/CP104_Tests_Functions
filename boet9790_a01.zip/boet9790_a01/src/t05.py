"""
-------------------------------------------------------
Assignment 1 Question 5
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------

"""
principal = float(input("Principal:"))
interest = float(input("Interest (%):"))
num_years = int(input("Number of years:"))
compund = int(input("Number of times interest compounded per year:"))

real_rate = (interest/100)
amount_money = principal * ((1+(real_rate/compund))**(num_years*compund))

print(f"Balance: $ {amount_money}")
