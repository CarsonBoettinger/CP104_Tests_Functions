"""
-------------------------------------------------------
Assignment 1 Question 4
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------

"""

cost_dosa = float(input("Cost of 1 dosa:"))

num_dosa = int(input("Number of dosa:"))

total_cost = cost_dosa * num_dosa

print(f"Total cost of {num_dosa} dosas: $ {total_cost}")