"""
-------------------------------------------------------
Lab 8 Test 1 
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""

from functions import get_weekday_name

for day_number in range(1, 8):
    print(f"Day {day_number}: {get_weekday_name(day_number)}")
