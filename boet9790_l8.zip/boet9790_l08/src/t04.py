"""
-------------------------------------------------------
Lab 8 Test 4 
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
from functions import generate_integer_list

result = generate_integer_list(10, -100, 100)
print(result)
