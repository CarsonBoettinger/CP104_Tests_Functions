"""
-------------------------------------------------------
Lab 8 Test 1 
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
from functions import linear_search

test_values = [94, 96, -22, -79, -28, -26, -50, 71, 24, -32]
search_value = -22
result = linear_search(test_values, search_value)
print(result)
