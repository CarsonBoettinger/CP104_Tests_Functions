"""
-------------------------------------------------------
Lab 8 Test 6 
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
from functions import generate_integer_list, list_stats

values = generate_integer_list(10, -100, 100)

result = list_stats(values)
print(result)
