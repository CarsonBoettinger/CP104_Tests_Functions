"""
-------------------------------------------------------
Test 2 Assignment 7
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-18"
-------------------------------------------------------
"""
from functions import list_positives


print("Enter positive numbers (enter 0 to stop):")
number_list = list_positives()
print("List of positive numbers entered:", number_list)