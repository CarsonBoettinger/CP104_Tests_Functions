"""
-------------------------------------------------------
Test 5 Assignment 7
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-18"
-------------------------------------------------------
"""
from functions import verify_sorted

list1 = [1, 2, 3, 4, 5]
list2 = [5, 4, 3, 2, 1]
list3 = [1, 3, 2, 4, 5]

print("List 1:", list1)
in_order, index = verify_sorted(list1)
print("Is sorted:", in_order)
print("First out-of-order index:", index)

print("\nList 2:", list2)
in_order, index = verify_sorted(list2)
print("Is sorted:", in_order)
print("First out-of-order index:", index)

print("\nList 3:", list3)
in_order, index = verify_sorted(list3)
print("Is sorted:", in_order)
print("First out-of-order index:", index)