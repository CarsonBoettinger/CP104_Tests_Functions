"""
-------------------------------------------------------
Test 4 Assignment 7
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-18"
-------------------------------------------------------
"""
from functions import list_subtract

minuend_list = [1, 2, 3, 4, 5, 2, 3]
subtrahend_list = [2, 3]

print("Before list_subtract:")
print("Minuend list:", minuend_list)
print("Subtrahend list:", subtrahend_list)

list_subtract(minuend_list, subtrahend_list)

print("\nAfter list_subtract:")
print("Minuend list:", minuend_list)