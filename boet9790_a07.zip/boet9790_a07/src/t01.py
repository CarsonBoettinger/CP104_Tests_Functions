"""
-------------------------------------------------------
Test 1 Assignment 7
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-18"
-------------------------------------------------------
"""
from functions import list_factors

test_cases = [6, 12, 20]

for number in test_cases:
    factors = list_factors(number)
    print(f"The factors of {number} are: {factors}")


