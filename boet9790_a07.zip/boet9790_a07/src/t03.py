"""
-------------------------------------------------------
Test 3 Assignment 7
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-18"
-------------------------------------------------------
"""
from functions import get_indexes

numbers1 = [5, 1, 8, 9, 5, 2, 5, 3]
target_number1 = 5

numbers2 = [1, 2, 3, 4, 5]
target_number2 = 2

numbers3 = [7, 7, 7, 7, 7, 7, 7]
target_number3 = 7

index_list1 = get_indexes(numbers1, target_number1)
index_list2 = get_indexes(numbers2, target_number2)
index_list3 = get_indexes(numbers3, target_number3)

print(f"Indexes of {target_number1} in {numbers1}: {index_list1}")
print(f"Indexes of {target_number2} in {numbers2}: {index_list2}")
print(f"Indexes of {target_number3} in {numbers3}: {index_list3}")