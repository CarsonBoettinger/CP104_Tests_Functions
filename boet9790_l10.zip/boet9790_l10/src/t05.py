"""
-------------------------------------------------------
Test 5 Lab 10
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""

from functions import customer_append


filename = 'customer.txt'


new_customer_record = ['67890', 'John', 'Doe', '800.75', '1999-05-15']

with open(filename, 'a') as file:
    customer_append(file, new_customer_record)
    print("Customer record appended successfully.")