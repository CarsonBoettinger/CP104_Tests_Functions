"""
-------------------------------------------------------
Test 10 Lab 10
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""
from functions import count_frequency_word

filename = 'words.txt'

with open(filename, 'r') as file:
    word_to_count = input("Word to count: ")
    count = count_frequency_word(file, word_to_count)
    print(f"'{word_to_count}' appears {count} time(s)")