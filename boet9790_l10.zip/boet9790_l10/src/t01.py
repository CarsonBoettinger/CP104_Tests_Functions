"""
-------------------------------------------------------
Test 1 Lab 10
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""
from functions import customer_record

filename = 'customer.txt'

with open(filename, 'r') as file:
    while True:
        try:
            record_number = int(input("Enter a record number: "))
            record = customer_record(file, record_number)
            print(record if record else "[]")
        except ValueError:
            print("Please enter a valid record number.")
        except IndexError:
            print("Record number out of range.")
        break  # Remove this break if you want to test multiple record numbers
