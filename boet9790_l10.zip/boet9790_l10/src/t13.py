"""
-------------------------------------------------------
Test 1 Lab 10
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""

from functions import file_copy

source_filename = 'words.txt'
target_filename = 'new_words.txt'


with open(source_filename, 'r') as source_file, open(target_filename, 'w') as target_file:
    file_copy(source_file, target_file)

print(f"Copying '{source_filename}' to '{target_filename}'")