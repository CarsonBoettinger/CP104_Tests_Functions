"""
-------------------------------------------------------
Lab 3 Question 11
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------

"""
location1 = "left"
location2 = "middle"
location3 = "right"

print(f"""
{location1:-<20s}
{location2:-^20s}
{location3:->20s}


""")