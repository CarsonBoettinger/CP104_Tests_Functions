"""
-------------------------------------------------------
Lab 3 Question 1
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------

"""
print(f"""
'I'm a Little Astronaut' by Jean Warren

I'm a little astronaut
    Flying to the moon.
        My rocket is ready,
        We blast off soon.
I climb aboard
    And close the hatch.
        5-4-3-2-1, off we blast!

""")