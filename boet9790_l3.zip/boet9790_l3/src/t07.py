"""
-------------------------------------------------------
Lab 3 Question 7
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------

"""
breakfast = float(input("Enter cost of breakfast:"))

lunch = float(input("Enter cost of lunch:"))

supper = float(input("Enter cost of supper:"))

bill = float(breakfast + lunch + supper)



print(f"""
Meal        Cost
Breakfast  ${breakfast:>6.2f}
Lunch      ${lunch:>6.2f}
Supper     ${supper:>6.2f}
Total      ${bill:>6.2f}
""")