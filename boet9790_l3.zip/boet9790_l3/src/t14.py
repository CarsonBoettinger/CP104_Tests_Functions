"""
-------------------------------------------------------
Lab 3 Question 14
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------

"""

minutes = int(input("Enter number of minutes:"))

days = minutes // 1440
hours = (minutes % 1440) // 60
min_answer = minutes % 60

print(f"There are {days} days, {hours} hours, and {min_answer} minutes in {minutes} minutes")