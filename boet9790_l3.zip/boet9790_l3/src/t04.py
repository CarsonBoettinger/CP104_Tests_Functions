"""
-------------------------------------------------------
Lab 3 Question 4
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------

"""
principal = float(input("Enter number:"))
percentage = float(input("Enter percent:"))

answer = principal * (percentage/100)

print(f"A {percentage} percent discount on {principal} is {answer:.1f}")