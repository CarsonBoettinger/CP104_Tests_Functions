"""
-------------------------------------------------------
Lab 3 Question 15
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------

"""
integer = 654321
decimal = 654.32
phrase = "Hello World"

print(f'{integer:d}')
#print(f'{integer:s}')
print(f'{integer:f}')

#print(f'{decimal:d}')
print(f'{decimal:f}')
#print(f'{decimal:s}')

#print(f'{phrase:d}')
#print(f'{phrase:f}')
print(f'{phrase:s}')