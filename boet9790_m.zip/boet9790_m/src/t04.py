"""
-------------------------------------------------------
Midterm A Task 4 Testing
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-10-29"
-------------------------------------------------------
"""
# Imports
# your imports here
from t04_functions import result
# your code here

response = input("Please input a response: ")

classification = result(response)

print("Classifcation", classification)

