"""
-------------------------------------------------------
Midterm A Task 3 Function Definitions
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-10-29"
-------------------------------------------------------
"""
# Constants

# your constants here
BASE_PRICE = 95
CPES = 35
VIP_DIS = 0.15
def servicing():
    """
    -------------------------------------------------------
    Determines the cost of getting a car cleaned. The cost is made up of:
        base cost: $95.00
        cost per extra service: $35.00
        VIP discount 15% only if:
            more than 1 extra service purchased
            and purchaser is a VIP
    The function must ask the user for these inputs.
    Use: cost = servicing()
    -------------------------------------------------------
    Returns‌‌​​‌​​‌​​​​‌​​​‌‌​​‌​‌​‌‌‌​:
        cost - cost of cleaning a car based upon the base cost,
            the number of extra services purchased, and VIP discount
            if applicable (float)
    -------------------------------------------------------
    """

    # your code here
    extra_service = (int(input("How many extra services are you purchasing?")))
    cost = BASE_PRICE + CPES * extra_service
    if extra_service > 1:
        vip = input("Are you a VIP member (Y/N)?")
        if vip == "Y":
            cost = cost*(1-VIP_DIS)

    return cost
