"""
-------------------------------------------------------
Assignment 4 Question 5
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-10-20"
-------------------------------------------------------
"""
from functions import hoo_rah


test_cases = [14, -43, 49]

for num in test_cases:
    result = hoo_rah(num)
    print(f"For the number {num}, the result is: {result}.")
