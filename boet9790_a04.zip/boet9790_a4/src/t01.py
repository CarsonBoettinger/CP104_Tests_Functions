"""
-------------------------------------------------------
Assignment 4 Question 1
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-10-20"
-------------------------------------------------------
"""
from functions import day_name


test_cases = [1, 2, 3, 4, 5, 6, 7, 0, 8]

for day_num in test_cases:
    day = day_name(day_num)
    print(f"Day number {day_num} corresponds to {day}.")

