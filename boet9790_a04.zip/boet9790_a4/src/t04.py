"""
-------------------------------------------------------
Assignment 4 Question 4
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-10-20"
-------------------------------------------------------
"""

from functions import colour_combine

test_cases = [("red", "blue"), ("red", "green"), ("green", "blue"), ("red", "red"), ("blue", "blue"), ("green", "green"), ("yellow", "red")]

for colours in test_cases:
    result = colour_combine(*colours)
    print(f"The secondary color for {colours[0]} and {colours[1]} is: {result}.")
