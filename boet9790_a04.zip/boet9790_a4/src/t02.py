"""
-------------------------------------------------------
Assignment 4 Question 2
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-10-20"
-------------------------------------------------------
"""

from functions import pollution_ranking

test_cases = [-10, 25, 75, 125, 175, 250, 350]

for i in test_cases:
    pollution_level = pollution_ranking(i)
    print(f"For an AQI of {i}, the pollution level is: {pollution_level}.")
