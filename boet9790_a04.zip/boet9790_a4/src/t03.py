"""
-------------------------------------------------------
Assignment 4 Question 3
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-10-28"
-------------------------------------------------------
"""
from functions import largest_average


test_cases = [(-8.0, 12.0, 20.0), (5.0, 5.0, 5.0), (10.0, 20.0, 30.0)]

for vals in test_cases:
    result = largest_average(*vals)
    print(f"For the values {vals}, the largest average is: {result}.")
