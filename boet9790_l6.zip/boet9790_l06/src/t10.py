"""
-------------------------------------------------------
Lab 6 Question 10
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-10-20"
-------------------------------------------------------
"""

from functions import treadmill

# Sample execution
treadmill(5.5, 10, 30, 5)
