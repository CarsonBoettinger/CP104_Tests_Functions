"""
-------------------------------------------------------
Lab 6 Question 5
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-10-20"
-------------------------------------------------------
"""

from functions import draw_rectangle

height = int(input("Enter height in characters: "))
width = int(input("Enter width in characters: "))
draw_char = input("Enter the draw character: ")
draw_rectangle(height, width, draw_char)
