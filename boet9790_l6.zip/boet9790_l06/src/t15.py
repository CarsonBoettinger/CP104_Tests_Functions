"""
-------------------------------------------------------
Lab 6 Question 15
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-10-20"
-------------------------------------------------------
"""

from functions import statistics


n = 5  
minimum, maximum, total, average = statistics(n)
print(f"Minimum: {minimum}")
print(f"Maximum: {maximum}")
print(f"Total: {total}")
print(f"Average: {average}")
