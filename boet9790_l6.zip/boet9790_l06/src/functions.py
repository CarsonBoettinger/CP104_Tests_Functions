"""
-------------------------------------------------------
Lab 6 Functions 
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-10-20"
-------------------------------------------------------
"""

def sum_even(num):
    """
    -------------------------------------------------------
    Sums and returns the total of all even numbers from 2 to num (inclusive).
    Use: total = sum_even(num)
    -------------------------------------------------------
    Parameters:
        num - an integer (int > 0)
    Returns:
        total - sum of all even numbers from 2 to num (int)
    ------------------------------------------------------
    """
    total = 0
    for i in range(2, num + 1, 2):
        total += i
    return total

def draw_rectangle(height, width, char):
    """
    -------------------------------------------------------
    Prints a rectangle of height and width characters using
    the char character.
    Use: draw_rectangle(height, width, char)
    -------------------------------------------------------
    Parameters:
        height - number of characters high (int > 0)
        width - number of characters wide (int > 0)
        char - the character to draw with (str, len() == 1)
    Returns:
        None
    ------------------------------------------------------
    """
    if height <= 0 or width <= 0 or len(char) != 1:
        print("Invalid input parameters.")
        return

    for i in range(height):
        for j in range(width):
            print(char, end='')
        print()

    
def bottles_of_beer(n):
    """
    -------------------------------------------------------
    Prints n verses of the song "99 Bottles of Beer on the Wall".
    Use: bottles_of_beer(n)
    -------------------------------------------------------
    Parameters:
        n - number of verses of the song to print (int > 0)
    Returns:
        None
    ------------------------------------------------------
    """
    for i in range(n, 0, -1):
        is_one = i == 1
        is_two = i == 2
        bottle_plural = '' if is_one else 's'
        next_bottle_plural = '' if is_two else 's'
        print(f"{i} bottle{bottle_plural} of beer on the wall, {i} bottle{bottle_plural} of beer.")
        print(f"Take one down and pass it around, {i-1 or 'no more'} bottle{next_bottle_plural} of beer on the wall.\n")
# functions.py

def treadmill(burnt_per_minute, start, end, inc):
    """
    -------------------------------------------------------
    Calculates and prints calories burnt on a treadmill over
    a given time range.
    Use: treadmill(burnt_per_minute, start, end, inc)
    -------------------------------------------------------
    Parameters:
        burnt_per_minute - calories burnt per minute (float > 0)
        start - start time in minutes (int > 0)
        end - end time in minutes (int >= start)
        inc - increment in minutes (int > 0)
    Returns:
        None
    ------------------------------------------------------
    """
    for i in range(start, end+1, inc):
        calories_burnt = i * burnt_per_minute
        print(f"Calories burned after {i} minutes: {calories_burnt:.1f}")




def statistics(n):
    """
    -------------------------------------------------------
    Asks a user to enter n values, then calculates and returns
    the minimum, maximum, total, and average of those values.
    Use: minimum, maximum, total, average = statistics(n)
    -------------------------------------------------------
    Parameters:
        n - number of values to process (int > 0)
    Returns:
        minimum - smallest of n values (float)
        maximum - largest of n values (float)
        total - total of n values (float)
        average - average of n values (float)
    ------------------------------------------------------
    """
    total = 0
    minimum = float('inf')
    maximum = float('-inf')


    for i in range(n):
        value = float(input(f"Enter value {i + 1}: "))
        total += value
        if value < minimum:
            minimum = value
        if value > maximum:
            maximum = value

    average = total / n

    return minimum, maximum, total, average










