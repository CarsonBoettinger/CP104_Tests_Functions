
"""
-------------------------------------------------------
Lab 6 Question 9
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-10-20"
-------------------------------------------------------
"""

from functions import bottles_of_beer

# Sample execution
bottles_of_beer(99)
