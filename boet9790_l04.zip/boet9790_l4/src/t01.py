"""
-------------------------------------------------------
Lab 4 Question 1
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-10-06"
-------------------------------------------------------
"""
from functions import diameter

radius = float(input("Input Raduis"))

a = diameter(radius)

print(f"{a}")