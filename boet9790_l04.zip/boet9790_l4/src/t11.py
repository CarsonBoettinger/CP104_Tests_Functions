"""
-------------------------------------------------------
Assignment 2 Question 1
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
x1 = int(input("Enter first x: "))     
y1 = int(input("Enter first y: "))     
x2 = int(input("Enter second x: "))     
y2 = int(input("Enter second y: "))      
    
