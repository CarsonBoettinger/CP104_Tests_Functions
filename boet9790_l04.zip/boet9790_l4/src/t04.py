"""
-------------------------------------------------------
Assignment 2 Question 1
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
from functions import square_pyramid
base=float(input("Length of base: "))
height=float(input("Perpendicular height of pyramid: "))
sh, area, vol=square_pyramid(base, height)
print(f"Slant height of square pyramid: {sh}")
print(f"Area of square pyramid: {area}")
print(f"Volume of square pyramid: {vol}")




