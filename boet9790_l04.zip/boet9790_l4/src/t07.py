"""
-------------------------------------------------------
Assignment 2 Question 1
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
from functions import total_change

nickles=int(input("Enter number of nickles "))

dimes=int(input("Enter number of dimes "))

quarters=int(input("Enter number of quarters "))

loonies=int(input("Enter number of loonies "))

toonies=int(input("Enter number of toonies "))
total = total_change(nickles, dimes, quarters,loonies, toonies)


print("Total amount: ${}".format(total))
