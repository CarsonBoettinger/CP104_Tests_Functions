"""
-------------------------------------------------------
Assignment 2 Question 1
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
TAX = 18.5
sales = float(input("Enter the total sales:"))

final_tax = sales * (TAX/100)
print(f"""
Projected Tax Report
--------------------------
Total sales:   $ {sales:.2f}
Annual tax:    % {TAX:.2f}
--------------------------
Tax:           $ {final_tax:.2f}
""")

