"""
-------------------------------------------------------
Assignment 2 Question 2
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
number = int(input("Enter a positive digit number:"))

if 10 <= number <= 99:
        tens_digit = number // 10
        ones_digit = number % 10
        difference = tens_digit - ones_digit
        print(f"The difference of the digits of {number} is {difference}")