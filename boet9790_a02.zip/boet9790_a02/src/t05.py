"""
-------------------------------------------------------
Assignment 2 Question 5
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""


foundation_length = float(input("Foundation length (m): "))
foundation_width = float(input("Foundation width (m): "))
foundation_height = float(input("Foundation height (m): "))
wall_height = float(input("Wall height (m): "))
cost_concrete_per_m3 = float(input("Cost of concrete ($/m^3): "))
cost_bricks_per_m2 = float(input("Cost of bricks ($/m^2): "))


foundation_volume = foundation_length * foundation_width * foundation_height


wall_area = 2 * (foundation_length * wall_height + foundation_width * wall_height)

bricks_volume = wall_area

total_cost_concrete = foundation_volume * cost_concrete_per_m3
total_cost_bricks = bricks_volume * cost_bricks_per_m2


print(f"Concrete needed for foundation (m^3): {foundation_volume:.2f}")
print(f"Cost of concrete: ${total_cost_concrete:.2f}")
print(f"Bricks needed for walls (m^2): {bricks_volume:.2f}")
print(f"Cost of bricks: ${total_cost_bricks:.2f}")

total_cost = total_cost_concrete + total_cost_bricks
print(f"Total cost: ${total_cost:.2f}")