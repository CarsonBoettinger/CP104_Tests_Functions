"""
-------------------------------------------------------
Assignment 2 Question 2
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
date = int(input("Enter a date in the format YYYYMMDD: "))
year = date // 10000
month = (date % 10000) // 100
day = date % 100
print(f"The reformatted date: {year}/{month}/{day}")