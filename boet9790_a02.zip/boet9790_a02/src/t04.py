"""
-------------------------------------------------------
Assignment 2 Question 4
Fall 2023
-------------------------------------------------------
Author: Carson Boettinger
ID:     210799790
Email:  boet9790@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
num_flyer = int(input("Number of flyers:"))
num_delivery = int(input("Number of delivery people:"))

flyer_per_person = (num_flyer // num_delivery)
flyers_left_over = (num_flyer % num_delivery)

print(f"Flyers per delivery person: {flyer_per_person}")
print(f"Flyers left over: {flyers_left_over}")